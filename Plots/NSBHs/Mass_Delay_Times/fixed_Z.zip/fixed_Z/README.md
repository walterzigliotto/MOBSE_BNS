fixed_Z plots.
