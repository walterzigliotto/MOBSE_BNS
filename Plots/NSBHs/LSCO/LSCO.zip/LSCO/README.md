Last Stable Circular Orbit (LSCO) plots.
